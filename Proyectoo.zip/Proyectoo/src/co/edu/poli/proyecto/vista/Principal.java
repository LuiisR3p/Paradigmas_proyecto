package co.edu.poli.proyecto.vista;

import co.edu.poli.proyecto.modelo.*;
import co.edu.poli.proyecto.servicios.*;
import java.io.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

/** Clase principal que ejecuta la lógica del sistema de reservas. */
public class Principal {

    /** Método principal para iniciar la aplicación.
     * @param args argumentos de línea de comandos */
    public static void main(String[] args) {
        SistemaReserva sistemaReserva = new SistemaReserva();
        Administrador administrador = new Administrador();
        ImplementacionOperacion operacion = new ImplementacionOperacion();
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;
        boolean esAdministrador = false;

        System.out.print("Ingresa tu rol (Usuario/Administrador): ");
        String rol = scanner.nextLine().toLowerCase();

        // Autenticación para administrador
        if (rol.equals("administrador")) {
            System.out.print("Ingresa el PIN de 4 dígitos: ");
            int pinIngresado = scanner.nextInt();
            scanner.nextLine();
            if (pinIngresado == 0000) {
                esAdministrador = true;
                System.out.println("Acceso concedido como administrador.");
            } else {
                System.out.println("PIN incorrecto. No tienes permisos de administrador.");
            }
        }

        while (continuar) {
            if (esAdministrador) {
                mostrarMenuAdministrador(sistemaReserva, administrador, scanner);
            } else {
                mostrarMenuUsuario(sistemaReserva, operacion, scanner);
            }
        }

        scanner.close();
    }

    /** Muestra el menú para administradores.
     * @param sistemaReserva instancia del sistema de reservas
     * @param administrador instancia del administrador
     * @param scanner entrada de datos del usuario */
    private static void mostrarMenuAdministrador(SistemaReserva sistemaReserva, Administrador administrador, Scanner scanner) {
        System.out.println("\nMenú para Administrador:");
        System.out.println("1. Ver todas las Reservas");
        System.out.println("2. Aprobar/Rechazar una Reserva");
        System.out.println("3. Salir");
        System.out.print("Selecciona una opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1 -> listarReservas(sistemaReserva);
            case 2 -> gestionarReservas(sistemaReserva, administrador, scanner);
            case 3 -> {
                System.out.println("Saliendo del sistema...");
                System.exit(0);
            }
            default -> System.out.println("Opción no válida, intenta nuevamente.");
        }
    }

    /** Muestra el menú para usuarios.
     * @param sistemaReserva instancia del sistema de reservas
     * @param operacion instancia de operaciones de serialización
     * @param scanner entrada de datos del usuario */
    private static void mostrarMenuUsuario(SistemaReserva sistemaReserva, ImplementacionOperacion operacion, Scanner scanner) {
        System.out.println("\nMenú CRUD de Reservas:");
        System.out.println("1. Crear Reserva");
        System.out.println("2. Leer Reserva");
        System.out.println("3. Actualizar Reserva");
        System.out.println("4. Eliminar Reserva");
        System.out.println("5. Serializar Reservas");
        System.out.println("6. Deserializar Reservas");
        System.out.println("7. Salir");
        System.out.print("Selecciona una opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
        case 1:
            // Crear una reserva
            System.out.println("=== Crear Reserva ===");
            System.out.print("ID de la Reserva: ");
            String id = scanner.nextLine();
            System.out.print("Fecha de inicio (yyyy-MM-dd HH:mm): ");
            String fechaInicioStr = scanner.nextLine().replace(" ", "T");
            System.out.print("Fecha de fin (yyyy-MM-dd HH:mm): ");
            String fechaFinStr = scanner.nextLine().replace(" ", "T");
            System.out.print("Propósito: ");
            String proposito = scanner.nextLine();

            LocalDateTime fechaInicio = LocalDateTime.parse(fechaInicioStr);
            LocalDateTime fechaFin = LocalDateTime.parse(fechaFinStr);
            EspacioPublico espacioPublico = new EspacioPublico(id); // Aquí puedes modificar según los espacios disponibles

            Reserva nuevaReserva = new Reserva(id, fechaInicio.toString(), fechaFin.toString(), proposito, espacioPublico);
            sistemaReserva.crearReserva(nuevaReserva);
            break;
        }
    }

    /** Lista todas las reservas del sistema.
     * @param sistemaReserva instancia del sistema de reservas */
    private static void listarReservas(SistemaReserva sistemaReserva) {
        System.out.println("=== Listado de Todas las Reservas ===");
        List<Reserva> todasLasReservas = sistemaReserva.getListaReservas();
        if (todasLasReservas.isEmpty()) {
            System.out.println("No hay reservas disponibles.");
        } else {
            todasLasReservas.forEach(System.out::println);
        }
    }

    /** Gestiona la aprobación o rechazo de una reserva.
     * @param sistemaReserva instancia del sistema de reservas
     * @param administrador instancia del administrador
     * @param scanner entrada de datos del usuario */
    private static void gestionarReservas(SistemaReserva sistemaReserva, Administrador administrador, Scanner scanner) {
        System.out.print("ID de la Reserva que deseas aprobar o rechazar: ");
        String idReserva = scanner.nextLine();
        Reserva reservaSeleccionada = sistemaReserva.leerReserva(idReserva);
        if (reservaSeleccionada != null) {
            System.out.println("¿Qué deseas hacer con esta reserva?");
            System.out.println("1. Aprobar");
            System.out.println("2. Rechazar");
            int decision = scanner.nextInt();
            scanner.nextLine();
            if (decision == 1) {
                administrador.aprobarReserva(reservaSeleccionada);
            } else if (decision == 2) {
                administrador.rechazarReserva(reservaSeleccionada);
            } else {
                System.out.println("Opción no válida.");
            }
        } else {
            System.out.println("No se encontró la reserva con ID: " + idReserva);
        }
    }

    /** Crea una nueva reserva.
     * @param sistemaReserva instancia del sistema de reservas
     * @param scanner entrada de datos del usuario */
    private static void crearReserva(SistemaReserva sistemaReserva, Scanner scanner) {
        try {
            System.out.print("ID de la Reserva: ");
            String id = scanner.nextLine();
            System.out.print("Fecha de inicio (yyyy-MM-dd HH:mm): ");
            LocalDateTime fechaInicio = LocalDateTime.parse(scanner.nextLine().replace(" ", "T"));
            System.out.print("Fecha de fin (yyyy-MM-dd HH:mm): ");
            LocalDateTime fechaFin = LocalDateTime.parse(scanner.nextLine().replace(" ", "T"));
            System.out.print("Propósito: ");
            String proposito = scanner.nextLine();
            System.out.print("Espacio público: ");
            String espacioNombre = scanner.nextLine().trim();
            EspacioPublico espacioPublico = new EspacioPublico(espacioNombre);
            sistemaReserva.crearReserva(new Reserva(id, fechaInicio.toString(), fechaFin.toString(), proposito, espacioPublico));
        } catch (Exception e) {
            System.out.println("Error al crear la reserva: " + e.getMessage());
        }
    }

    // Métodos adicionales para leer, actualizar, eliminar, serializar y deserializar...
}
