package co.edu.poli.proyecto.servicios;

import java.io.IOException;
import java.util.List;
import co.edu.poli.proyecto.modelo.Reserva;

/** Interfaz que define las operaciones CRUD y de serialización para las reservas. */
public interface Interface1 {

    /** Crea una nueva reserva.
     * @param reserva la reserva que se desea crear */
    void create(Reserva reserva);

    /** Lee una reserva por su ID.
     * @param id el identificador único de la reserva
     * @return la reserva encontrada, o null si no existe */
    Reserva read(int id);

    /** Actualiza una reserva existente.
     * @param id el identificador único de la reserva a actualizar
     * @param reserva la reserva con los nuevos datos */
    void update(int id, Reserva reserva);

    /** Elimina una reserva por su ID.
     * @param id el identificador único de la reserva a eliminar */
    void delete(int id);

    /** Serializa un array de reservas a un archivo.
     * @param reservas el array de reservas a serializar
     * @param path la ruta del archivo de destino
     * @param name el nombre asociado a las reservas (opcional)
     * @return mensaje indicando el éxito o error de la operación
     * @throws IOException si ocurre un error de escritura */
    String serializar(Reserva[] reservas, String path, String name) throws IOException;

    /** Deserializa un archivo de reservas a una lista.
     * @param path la ruta del archivo fuente
     * @param name el nombre asociado a las reservas (opcional)
     * @return lista de reservas deserializadas
     * @throws IOException si ocurre un error de lectura
     * @throws ClassNotFoundException si el archivo no contiene objetos válidos */
    List<Reserva> deserializar(String path, String name) throws IOException, ClassNotFoundException;
}
