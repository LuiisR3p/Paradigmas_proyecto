package co.edu.poli.proyecto.servicios;

import co.edu.poli.proyecto.modelo.Reserva;

import java.io.*;
import java.util.*;

/** Clase que implementa las operaciones CRUD y serialización para las reservas. */
public class ImplementacionOperacion implements Interface1 {

    /** Crea una nueva reserva. 
     * @param reserva la reserva que se desea crear */
    @Override
    public void create(Reserva reserva) {
        // TODO: Implementar lógica para crear la reserva
    }

    /** Lee una reserva por su ID. 
     * @param id el identificador único de la reserva
     * @return la reserva encontrada, o null si no existe */
    @Override
    public Reserva read(int id) {
        // TODO: Implementar lógica para leer la reserva por ID
        return null;
    }

    /** Actualiza una reserva existente. 
     * @param id el identificador único de la reserva a actualizar
     * @param reserva la reserva con los nuevos datos */
    @Override
    public void update(int id, Reserva reserva) {
        // TODO: Implementar lógica para actualizar la reserva
    }

    /** Elimina una reserva por su ID. 
     * @param id el identificador único de la reserva a eliminar */
    @Override
    public void delete(int id) {
        // TODO: Implementar lógica para eliminar la reserva
    }

    /** Serializa un array de reservas a un archivo. 
     * @param reservas el array de reservas a serializar
     * @param path la ruta del archivo de destino
     * @param name el nombre asociado a las reservas (opcional)
     * @return mensaje indicando el éxito o error de la operación
     * @throws IOException si ocurre un error de escritura */
    @Override
    public String serializar(Reserva[] reservas, String path, String name) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(reservas);
            return "Reservas serializadas correctamente.";
        } catch (IOException e) {
            return "Error al serializar reservas: " + e.getMessage();
        }
    }

    /** Deserializa un archivo de reservas a una lista. 
     * @param path la ruta del archivo fuente
     * @param name el nombre asociado a las reservas (opcional)
     * @return lista de reservas deserializadas
     * @throws IOException si ocurre un error de lectura
     * @throws ClassNotFoundException si el archivo no contiene objetos válidos */
    @Override
    public List<Reserva> deserializar(String path, String name) throws IOException, ClassNotFoundException {
        List<Reserva> reservas = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))) {
            Reserva[] reservasArray = (Reserva[]) ois.readObject();
            reservas = Arrays.asList(reservasArray);
        }
        return reservas;
    }
}


