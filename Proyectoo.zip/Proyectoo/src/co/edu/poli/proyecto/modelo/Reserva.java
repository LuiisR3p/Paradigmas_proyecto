package co.edu.poli.proyecto.modelo;

import java.io.Serializable;

/** Clase que representa una reserva en un espacio público. */
public class Reserva implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String fechaInicio;
    private String fechaFin;
    private String proposito;
    private EspacioPublico espacioPublico;

    /** Constructor que inicializa los detalles de la reserva.
     * @param id identificador único de la reserva
     * @param fechaInicio fecha y hora de inicio de la reserva
     * @param fechaFin fecha y hora de fin de la reserva
     * @param proposito propósito de la reserva
     * @param espacioPublico espacio público asociado a la reserva */
    public Reserva(String id, String fechaInicio, String fechaFin, String proposito, EspacioPublico espacioPublico) {
        this.id = id;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.proposito = proposito;
        this.espacioPublico = espacioPublico;
    }

    /** Obtiene el ID de la reserva. 
     * @return el ID de la reserva */
    public String getId() {
        return id;
    }

    /** Obtiene la fecha de inicio de la reserva. 
     * @return la fecha de inicio */
    public String getFechaInicio() {
        return fechaInicio;
    }

    /** Obtiene la fecha de fin de la reserva. 
     * @return la fecha de fin */
    public String getFechaFin() {
        return fechaFin;
    }

    /** Obtiene el propósito de la reserva. 
     * @return el propósito de la reserva */
    public String getProposito() {
        return proposito;
    }

    /** Obtiene el espacio público asociado a la reserva. 
     * @return el espacio público */
    public EspacioPublico getEspacioPublico() {
        return espacioPublico;
    }

    /** Establece un nuevo ID para la reserva. 
     * @param id el nuevo ID */
    public void setId(String id) {
        this.id = id;
    }

    /** Establece la fecha de inicio de la reserva. 
     * @param fechaInicio la nueva fecha de inicio */
    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /** Establece la fecha de fin de la reserva. 
     * @param fechaFin la nueva fecha de fin */
    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    /** Establece un nuevo propósito para la reserva. 
     * @param proposito el nuevo propósito */
    public void setProposito(String proposito) {
        this.proposito = proposito;
    }

    /** Establece un nuevo espacio público para la reserva. 
     * @param espacioPublico el nuevo espacio público */
    public void setEspacioPublico(EspacioPublico espacioPublico) {
        this.espacioPublico = espacioPublico;
    }

    /** Devuelve una representación en cadena de la reserva. 
     * @return una cadena con los detalles de la reserva */
    @Override
    public String toString() {
        return String.format("ID: %s, Inicio: %s, Fin: %s, Propósito: %s, Espacio Público: %s",
                id, fechaInicio, fechaFin, proposito, espacioPublico.getNombre());
    }

    /** Establece el estado de la reserva. 
     * (Método a implementar) */
    public void setEstado(String estado) {
        // TODO: Implementar lógica para establecer el estado
    }

    /** Obtiene el responsable de la reserva. 
     * (Método a implementar) 
     * @return el responsable de la reserva */
    public Object getResponsable() {
        // TODO: Implementar lógica para obtener el responsable
        return null;
    }

    /** Establece el responsable de la reserva. 
     * (Método a implementar) 
     * @param responsable el responsable de la reserva */
    public void setResponsable(Object responsable) {
        // TODO: Implementar lógica para establecer el responsable
    }

    /** Obtiene el lugar de la reserva. 
     * (Método a implementar) 
     * @return el lugar de la reserva */
    public Object getLugar() {
        // TODO: Implementar lógica para obtener el lugar
        return null;
    }

    /** Establece el lugar de la reserva. 
     * (Método a implementar) 
     * @param lugar el lugar de la reserva */
    public void setLugar(Object lugar) {
        // TODO: Implementar lógica para establecer el lugar
    }
}

