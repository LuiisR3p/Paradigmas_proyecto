package co.edu.poli.proyecto.modelo;

/** Clase que representa a un administrador encargado de gestionar las reservas. */
public class Administrador {
    private String nombre;
    private String id;

    /** Constructor por defecto. */
    public Administrador() {}

    /** Aprueba una reserva cambiando su estado a "Aprobada". 
     * @param reserva la reserva que se desea aprobar */
    public void aprobarReserva(Reserva reserva) {
        if (reserva != null) {
            reserva.setEstado("Aprobada");
            System.out.println("Reserva aprobada.");
        }
    }

    /** Rechaza una reserva cambiando su estado a "Rechazada". 
     * @param reserva la reserva que se desea rechazar */
    public void rechazarReserva(Reserva reserva) {
        if (reserva != null) {
            reserva.setEstado("Rechazada");
            System.out.println("Reserva rechazada.");
        }
    }

    /** Revisa posibles conflictos entre las reservas. (Método aún no implementado). */
    public void revisarConflictos() {
        // TODO: Implementar lógica para revisar conflictos
    }
}
