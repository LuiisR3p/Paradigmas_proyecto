package co.edu.poli.proyecto.modelo;

import java.util.*;

/** Clase que gestiona las reservas mediante operaciones CRUD. */
public class SistemaReserva {
    private List<Reserva> listaReservas = new ArrayList<>();
    private Map<String, Reserva> mapaReservas = new HashMap<>();

    /** Constructor por defecto. */
    public SistemaReserva() {}

    /** Crea una nueva reserva si no existe un ID duplicado. 
     * @param reserva la reserva a crear */
    public void crearReserva(Reserva reserva) {
        if (!mapaReservas.containsKey(reserva.getId())) {
            listaReservas.add(reserva);
            mapaReservas.put(reserva.getId(), reserva);
            System.out.println("Reserva creada exitosamente.");
        } else {
            System.out.println("Ya existe una reserva con el ID: " + reserva.getId());
        }
    }

    /** Busca una reserva por su ID. 
     * @param id el identificador único de la reserva
     * @return la reserva correspondiente o null si no existe */
    public Reserva leerReserva(String id) {
        if (mapaReservas.containsKey(id)) {
            return mapaReservas.get(id);
        } else {
            System.out.println("No se encontró la reserva con ID: " + id);
            return null;
        }
    }

    /** Actualiza una reserva existente si su ID es válido. 
     * @param id el identificador único de la reserva a actualizar
     * @param nuevaReserva los nuevos datos de la reserva */
    public void actualizarReserva(String id, Reserva nuevaReserva) {
        if (mapaReservas.containsKey(id)) {
            Reserva reservaActual = mapaReservas.get(id);
            reservaActual.setFechaInicio(nuevaReserva.getFechaInicio());
            reservaActual.setFechaFin(nuevaReserva.getFechaFin());
            reservaActual.setResponsable(nuevaReserva.getResponsable());
            reservaActual.setLugar(nuevaReserva.getLugar());
            System.out.println("Reserva actualizada.");
        } else {
            System.out.println("No se encontró la reserva con ID: " + id);
        }
    }

    /** Elimina una reserva existente si su ID es válido. 
     * @param id el identificador único de la reserva a eliminar */
    public void eliminarReserva(String id) {
        if (mapaReservas.containsKey(id)) {
            Reserva reserva = mapaReservas.get(id);
            listaReservas.remove(reserva);
            mapaReservas.remove(id);
            System.out.println("Reserva eliminada.");
        } else {
            System.out.println("No se encontró la reserva con ID: " + id);
        }
    }

    /** Obtiene la lista de todas las reservas. 
     * @return la lista de reservas */
    public List<Reserva> getListaReservas() {
        return listaReservas;
    }
}

