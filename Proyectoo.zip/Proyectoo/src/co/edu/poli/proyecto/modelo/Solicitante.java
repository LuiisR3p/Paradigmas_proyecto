package co.edu.poli.proyecto.modelo;

import java.time.LocalDateTime;

/** Clase que representa un solicitante que puede realizar reservas de espacios públicos. */
public class Solicitante {

    private String nombre;
    private String contacto;

    /** Constructor por defecto. */
    public Solicitante() {}

    /** Crea una solicitud de reserva para un espacio público. 
     * @param espacioPublico el espacio público que se desea reservar
     * @param fechaInicio la fecha y hora de inicio de la reserva
     * @param fechaFin la fecha y hora de fin de la reserva */
    public void crearSolicitud(EspacioPublico espacioPublico, LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        // TODO: Implementar lógica para crear solicitud de reserva
    }

    /** Consulta las reservas asociadas al solicitante. */
    public void consultarReservas() {
        // TODO: Implementar lógica para consultar las reservas del solicitante
    }

    /** Actualiza la información del perfil del solicitante. */
    public void actualizarPerfil() {
        // TODO: Implementar lógica para actualizar el perfil del solicitante
    }
}
