package co.edu.poli.proyecto.modelo;

import java.io.Serializable;

/** Clase que representa un espacio público, como parques o lugares en la ciudad. */
public class EspacioPublico implements Serializable {
    private static final long serialVersionUID = 1L;
    private String nombre;

    /** Constructor que inicializa el nombre del espacio público. 
     * @param nombre el nombre del espacio público */
    public EspacioPublico(String nombre) {
        this.nombre = nombre;
    }

    /** Obtiene el nombre del espacio público. 
     * @return el nombre del espacio público */
    public String getNombre() {
        return nombre;
    }

    /** Establece un nuevo nombre para el espacio público. 
     * @param nombre el nuevo nombre del espacio público */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /** Devuelve una representación en cadena del espacio público. 
     * @return el nombre del espacio público */
    @Override
    public String toString() {
        return nombre;
    }
}
