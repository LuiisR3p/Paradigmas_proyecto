package co.edu.poli.demo.proyecto.vista;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Clase principal que inicializa la aplicación JavaFX.
 * Se encarga de cargar el archivo FXML y configurar la escena principal.
 */
public class Main extends Application {
    /**
     * Método que inicia la aplicación JavaFX.
     * @param primaryStage la ventana principal de la aplicación
     * @throws Exception si ocurre un error al cargar el archivo FXML
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/co/edu/poli/demo/proyecto/vista/Principal.fxml"));
        primaryStage.setTitle("Sistema de Reservas");
        primaryStage.setScene(new Scene(root, 800, 600)); // Ajusta el tamaño de la ventana
        primaryStage.show();
    }

    /**
     * Método principal que lanza la aplicación JavaFX.
     * @param args argumentos de línea de comandos
     */
    public static void main(String[] args) {
        launch(args);
    }
}
