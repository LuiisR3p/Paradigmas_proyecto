package co.edu.poli.demo.proyecto.controlador;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PrincipalControlador extends Application {

    private static final String FILE_PATH = "reservas.dat";
    private static final String ADMIN_PASSWORD = "123456"; // Clave del administrador

    private final List<String> espaciosPublicos = List.of(
            "Parque Simón Bolívar", 
            "Parque de los Novios", 
            "Parque El Virrey", 
            "Parque La 93", 
            "Parque Nacional", 
            "Jardín Botánico", 
            "Monserrate"
    );

    private final ObservableList<Reserva> reservasObservableList = FXCollections.observableArrayList();

    private TableView<Reserva> tableViewReservas;
    private TextArea textAreaMensajes;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Selector de Roles");

        // Botones para seleccionar roles
        Button btnUsuario = new Button("Entrar como Usuario");
        btnUsuario.setOnAction(event -> mostrarVistaUsuario(primaryStage));

        Button btnAdministrador = new Button("Entrar como Administrador");
        btnAdministrador.setOnAction(event -> {
            if (verificarClaveAdministrador()) {
                mostrarVistaAdministrador(primaryStage);
            } else {
                mostrarMensajeError("Error", "Clave incorrecta. Acceso denegado.");
            }
        });

        // Layout inicial
        VBox layout = new VBox(10, btnUsuario, btnAdministrador);
        layout.setPrefSize(300, 150);
        layout.setStyle("-fx-alignment: center; -fx-spacing: 20;");
        Scene scene = new Scene(layout);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private boolean verificarClaveAdministrador() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Acceso de Administrador");
        dialog.setHeaderText("Ingrese la clave de administrador:");
        dialog.setContentText("Clave:");
        Optional<String> result = dialog.showAndWait();
        return result.isPresent() && result.get().equals(ADMIN_PASSWORD);
    }

    private void mostrarVistaUsuario(Stage stage) {
        configurarVista(stage, "Sistema de Reservas - Usuario", crearBotonesUsuario());
    }

    private void mostrarVistaAdministrador(Stage stage) {
        configurarVista(stage, "Sistema de Reservas - Administrador", crearBotonesAdministrador());
    }

    private void configurarVista(Stage stage, String titulo, VBox botones) {
        tableViewReservas = new TableView<>();
        TableColumn<Reserva, String> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn<Reserva, String> colFechaInicio = new TableColumn<>("Fecha Inicio");
        colFechaInicio.setCellValueFactory(new PropertyValueFactory<>("fechaInicio"));
        TableColumn<Reserva, String> colFechaFin = new TableColumn<>("Fecha Fin");
        colFechaFin.setCellValueFactory(new PropertyValueFactory<>("fechaFin"));
        TableColumn<Reserva, String> colResponsable = new TableColumn<>("Responsable");
        colResponsable.setCellValueFactory(new PropertyValueFactory<>("responsable"));
        TableColumn<Reserva, String> colLugar = new TableColumn<>("Lugar");
        colLugar.setCellValueFactory(new PropertyValueFactory<>("lugar"));
        TableColumn<Reserva, String> colEstado = new TableColumn<>("Estado");
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        tableViewReservas.getColumns().addAll(colId, colFechaInicio, colFechaFin, colResponsable, colLugar, colEstado);
        tableViewReservas.setItems(reservasObservableList);

        textAreaMensajes = new TextArea();
        textAreaMensajes.setEditable(false);

        VBox layout = new VBox(10, tableViewReservas, botones, textAreaMensajes);
        layout.setPrefSize(800, 600);
        Scene scene = new Scene(layout);
        stage.setTitle(titulo);
        stage.setScene(scene);
    }

    private VBox crearBotonesUsuario() {
        Button btnCrearReserva = new Button("Crear Reserva");
        btnCrearReserva.setOnAction(event -> crearReserva());

        Button btnLeerReserva = new Button("Leer Reserva");
        btnLeerReserva.setOnAction(event -> leerReserva());

        Button btnActualizarReserva = new Button("Actualizar Reserva");
        btnActualizarReserva.setOnAction(event -> actualizarReserva());

        Button btnEliminarReserva = new Button("Eliminar Reserva");
        btnEliminarReserva.setOnAction(event -> eliminarReserva());

        Button btnSerializar = new Button("Serializar Reservas");
        btnSerializar.setOnAction(event -> serializarReservas());

        Button btnDeserializar = new Button("Deserializar Reservas");
        btnDeserializar.setOnAction(event -> deserializarReservas());

        Button btnSalir = new Button("Salir");
        btnSalir.setOnAction(event -> System.exit(0));

        return new VBox(10, btnCrearReserva, btnLeerReserva, btnActualizarReserva, btnEliminarReserva, btnSerializar, btnDeserializar, btnSalir);
    }

    private VBox crearBotonesAdministrador() {
        Button btnAprobarReserva = new Button("Aprobar Reserva");
        btnAprobarReserva.setOnAction(event -> aprobarReserva());

        Button btnRechazarReserva = new Button("Rechazar Reserva");
        btnRechazarReserva.setOnAction(event -> rechazarReserva());

        Button btnSerializar = new Button("Serializar Reservas");
        btnSerializar.setOnAction(event -> serializarReservas());

        Button btnDeserializar = new Button("Deserializar Reservas");
        btnDeserializar.setOnAction(event -> deserializarReservas());

        Button btnSalir = new Button("Salir");
        btnSalir.setOnAction(event -> System.exit(0));

        return new VBox(10, btnAprobarReserva, btnRechazarReserva, btnSerializar, btnDeserializar, btnSalir);
    }

    private void crearReserva() {
        String id = mostrarInputDialog("Crear Reserva", "Ingrese el ID de la Reserva:");
        LocalDate fechaInicio = mostrarSelectorFecha("Fecha de Inicio");
        LocalDate fechaFin = mostrarSelectorFecha("Fecha de Fin");
        String responsable = mostrarInputDialog("Responsable", "Ingrese el nombre del responsable:");
        String lugar = mostrarSelectorEspacioPublico();

        if (id != null && fechaInicio != null && fechaFin != null && responsable != null && lugar != null) {
            boolean conflicto = reservasObservableList.stream().anyMatch(r ->
                    r.getLugar().equals(lugar) &&
                    r.getFechaInicio().equals(fechaInicio.toString()) &&
                    r.getFechaFin().equals(fechaFin.toString()));

            if (conflicto) {
                mostrarMensajeError("Error", "Ya existe una reserva para este lugar en las mismas fechas.");
            } else {
                Reserva nuevaReserva = new Reserva(id, fechaInicio.toString(), fechaFin.toString(),
                        "Evento General", responsable, lugar);
                reservasObservableList.add(nuevaReserva);
                mostrarMensaje("Reserva creada exitosamente: " + nuevaReserva);
                actualizarTabla();
            }
        } else {
            mostrarMensajeError("Error", "No se pudo crear la reserva. Datos incompletos.");
        }
    }

    private void leerReserva() {
        String id = mostrarInputDialog("Leer Reserva", "Ingrese el ID de la Reserva:");
        if (id != null) {
            Reserva reserva = reservasObservableList.stream()
                    .filter(r -> r.getId().equals(id))
                    .findFirst()
                    .orElse(null);

            if (reserva != null) {
                mostrarMensaje("Detalles de la Reserva:\n" + reserva.toString());
            } else {
                mostrarMensajeError("Error", "No se encontró la reserva con ID: " + id);
            }
        }
    }

    private void actualizarReserva() {
        String id = mostrarInputDialog("Actualizar Reserva", "Ingrese el ID de la Reserva:");
        if (id != null) {
            Reserva reserva = reservasObservableList.stream()
                    .filter(r -> r.getId().equals(id))
                    .findFirst()
                    .orElse(null);

            if (reserva != null) {
                LocalDate nuevaFechaInicio = mostrarSelectorFecha("Nueva Fecha de Inicio");
                LocalDate nuevaFechaFin = mostrarSelectorFecha("Nueva Fecha de Fin");
                String nuevoResponsable = mostrarInputDialog("Nuevo Responsable", "Ingrese el nuevo responsable:");
                String nuevoLugar = mostrarSelectorEspacioPublico();

                if (nuevaFechaInicio != null && nuevaFechaFin != null && nuevoResponsable != null && nuevoLugar != null) {
                    reserva.setFechaInicio(nuevaFechaInicio.toString());
                    reserva.setFechaFin(nuevaFechaFin.toString());
                    reserva.setResponsable(nuevoResponsable);
                    reserva.setLugar(nuevoLugar);
                    mostrarMensaje("Reserva actualizada correctamente.");
                    actualizarTabla();
                } else {
                    mostrarMensajeError("Error", "No se pudieron actualizar los datos.");
                }
            } else {
                mostrarMensajeError("Error", "No se encontró la reserva con ID: " + id);
            }
        }
    }

    private void eliminarReserva() {
        String id = mostrarInputDialog("Eliminar Reserva", "Ingrese el ID de la Reserva:");
        if (id != null) {
            boolean eliminado = reservasObservableList.removeIf(r -> r.getId().equals(id));
            if (eliminado) {
                mostrarMensaje("Reserva eliminada: ID " + id);
                actualizarTabla();
            } else {
                mostrarMensajeError("Error", "No se encontró la reserva con ID: " + id);
            }
        }
    }

    private void aprobarReserva() {
        String id = mostrarInputDialog("Aprobar Reserva", "Ingrese el ID de la Reserva a aprobar:");
        if (id != null) {
            Reserva reserva = reservasObservableList.stream()
                    .filter(r -> r.getId().equals(id) && r.getEstado().equals("Pendiente"))
                    .findFirst()
                    .orElse(null);

            if (reserva != null) {
                reserva.setEstado("Aprobada");
                mostrarMensaje("Reserva aprobada: ID " + id);
                actualizarTabla();
            } else {
                mostrarMensajeError("Error", "No se encontró una reserva pendiente con ID: " + id);
            }
        }
    }

    private void rechazarReserva() {
        String id = mostrarInputDialog("Rechazar Reserva", "Ingrese el ID de la Reserva a rechazar:");
        if (id != null) {
            Reserva reserva = reservasObservableList.stream()
                    .filter(r -> r.getId().equals(id) && r.getEstado().equals("Pendiente"))
                    .findFirst()
                    .orElse(null);

            if (reserva != null) {
                reserva.setEstado("Rechazada");
                mostrarMensaje("Reserva rechazada: ID " + id);
                actualizarTabla();
            } else {
                mostrarMensajeError("Error", "No se encontró una reserva pendiente con ID: " + id);
            }
        }
    }

    private void serializarReservas() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            List<Reserva> listaParaSerializar = new ArrayList<>(reservasObservableList);
            oos.writeObject(listaParaSerializar);
            mostrarMensaje("Datos serializados correctamente.");
        } catch (IOException e) {
            mostrarMensajeError("Error", "No se pudo serializar los datos: " + e.getMessage());
        }
    }

    private void deserializarReservas() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            List<Reserva> listaDeserializada = (List<Reserva>) ois.readObject();
            reservasObservableList.clear();
            reservasObservableList.addAll(listaDeserializada);
            mostrarMensaje("Datos deserializados correctamente.");
            actualizarTabla();
        } catch (IOException | ClassNotFoundException e) {
            mostrarMensajeError("Error", "No se pudo deserializar los datos: " + e.getMessage());
        }
    }

    private void actualizarTabla() {
        tableViewReservas.refresh();
    }

    private LocalDate mostrarSelectorFecha(String titulo) {
        DatePicker datePicker = new DatePicker();
        Dialog<LocalDate> dialog = new Dialog<>();
        dialog.setTitle(titulo);
        dialog.getDialogPane().setContent(datePicker);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(buttonType -> buttonType == ButtonType.OK ? datePicker.getValue() : null);

        Optional<LocalDate> result = dialog.showAndWait();
        return result.orElse(null);
    }

    private String mostrarSelectorEspacioPublico() {
        ChoiceDialog<String> dialog = new ChoiceDialog<>(espaciosPublicos.get(0), espaciosPublicos);
        dialog.setTitle("Seleccionar Espacio Público");
        dialog.setHeaderText("Seleccione un espacio público en Bogotá:");
        dialog.setContentText("Espacio:");
        return dialog.showAndWait().orElse(null);
    }

    private String mostrarInputDialog(String titulo, String mensaje) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle(titulo);
        dialog.setHeaderText(mensaje);
        return dialog.showAndWait().orElse(null);
    }

    private void mostrarMensaje(String mensaje) {
        textAreaMensajes.appendText(mensaje + "\n");
    }

    private void mostrarMensajeError(String titulo, String mensaje) {
        textAreaMensajes.appendText("[ERROR] " + mensaje + "\n");
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    public static class Reserva implements Serializable {
        private static final long serialVersionUID = 1L;

        private String id;
        private String fechaInicio;
        private String fechaFin;
        private String proposito;
        private String responsable;
        private String lugar;
        private String estado;

        public Reserva(String id, String fechaInicio, String fechaFin, String proposito, String responsable, String lugar) {
            this.id = id;
            this.fechaInicio = fechaInicio;
            this.fechaFin = fechaFin;
            this.proposito = proposito;
            this.responsable = responsable;
            this.lugar = lugar;
            this.estado = "Pendiente";
        }

        public String getId() {
            return id;
        }

        public String getFechaInicio() {
            return fechaInicio;
        }

        public void setFechaInicio(String fechaInicio) {
            this.fechaInicio = fechaInicio;
        }

        public String getFechaFin() {
            return fechaFin;
        }

        public void setFechaFin(String fechaFin) {
            this.fechaFin = fechaFin;
        }

        public String getProposito() {
            return proposito;
        }

        public String getResponsable() {
            return responsable;
        }

        public void setResponsable(String responsable) {
            this.responsable = responsable;
        }

        public String getLugar() {
            return lugar;
        }

        public void setLugar(String lugar) {
            this.lugar = lugar;
        }

        public String getEstado() {
            return estado;
        }

        public void setEstado(String estado) {
            this.estado = estado;
        }

        @Override
        public String toString() {
            return String.format("ID: %s | Inicio: %s | Fin: %s | Responsable: %s | Lugar: %s | Estado: %s",
                    id, fechaInicio, fechaFin, responsable, lugar, estado);
        }
    }
}

