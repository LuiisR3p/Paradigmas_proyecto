module co.edu.poli.proyecto {
    requires javafx.controls;
    requires javafx.fxml;

    exports co.edu.poli.demo.proyecto.controlador;
}
